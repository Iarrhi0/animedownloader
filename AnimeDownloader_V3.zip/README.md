# Anime Downloader V3

Interface Android remaniée: recherche anime unifiée, fiches visuelles, épisodes, sélection multiple, choix de qualité et file de 3 téléchargements. Les métadonnées publiques utilisent Jikan/MyAnimeList. Les connecteurs de lecture/téléchargement doivent pointer vers des flux publics ou autorisés; aucun contournement DRM/authentification n'est inclus.
