# Anime Downloader V2

Android prototype with one unified search screen and a three-worker download queue.

## Included
- One search UI across configured public/authorized sources.
- Quality selection for HLS master playlists: Auto, 360p, 480p, 720p, 1080p when those variants exist.
- Multiple URLs accepted at once.
- Up to three concurrent downloads.
- Direct HTTP video and unprotected HLS support.
- GitHub Actions debug APK build.

The source adapter list is intentionally modular. Only add sources you are authorized to access/download from. The app does not bypass DRM, authentication, paywalls, or technical access controls.
